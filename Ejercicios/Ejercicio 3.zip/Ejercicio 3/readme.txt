Aclaraciones:

-Al final de la ol, le agregué un margin bottom ya que no estaba especificado si era necesario que el footer este separado del contenido o no, pero como en la foto no se veia trate de dejar ese espacio tambien.

-A la hora de marcar en negrita algunos objetos de las listas, varié entre usar la etiqueta STRONG o modificar el font-weight con CSS segun me parecio conveniente. Daniel nos explico que al usar STRONG se le da un peso distinto a la hora de las busquedas en google y el SEO, por ende, resalte con esta etiqueta las cosas que me parecieron relevantes, y utilice la propiedad de CSS para las palabras en negrita que a mi parecer no serian importantes que se indexen en SEO.