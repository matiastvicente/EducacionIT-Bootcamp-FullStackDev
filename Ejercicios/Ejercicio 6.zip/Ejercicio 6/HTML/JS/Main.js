/* Main */

var cantidadDeGatos, cantidadDePasos;
const VectorGatos=[ "😺","😸","😹"];
const VectorEmoticones=["🐈","🐾","⬛"];

//   A    //
do{
    cantidadDeGatos= window.prompt('Inciso A: Ingrese la cantidad de Gatos a imprimir','Cantidad de Gatos');
}
while (isNaN(cantidadDeGatos) || cantidadDeGatos <= 0); // Utilizamos la funcion isNaN para validar que la entrada sea un numero (si es decimal, utiliza solo la parte entera)
IncisoA(VectorGatos,cantidadDeGatos); 

//   B    //
do{
    cantidadDeGatos= window.prompt('Inciso B: Ingrese la cantidad de Gatos a imprimir','Cantidad de Gatos');
}
while (isNaN(cantidadDeGatos) || cantidadDeGatos <= 0);
do{
    cantidadDePasos= window.prompt('Inciso B: Ingrese la cantidad de Pasos a imprimir','Cantidad de Pasos');
}
while (isNaN(cantidadDePasos) || cantidadDePasos <= 0);
IncisoB(VectorEmoticones,cantidadDeGatos,cantidadDePasos);


//   C    //
do{
    cantidadDeGatos= window.prompt('Inciso C: Ingrese la cantidad de Gatos a imprimir','Cantidad de Gatos');
}
while (isNaN(cantidadDeGatos) || cantidadDeGatos <= 0);
do{
    cantidadDePasos= window.prompt('Inciso C: Ingrese la cantidad de Pasos a imprimir','Cantidad de Pasos');
}
while (isNaN(cantidadDePasos) || cantidadDePasos <= 0);
IncisoC(VectorEmoticones,cantidadDeGatos,cantidadDePasos);

/* Inciso A */

function IncisoA(VectorGatos,CantGatos){
    let i, j=0, Mensaje;

    console.log(/-----------IncisoA-----------/);

    for(i=0; i<CantGatos; i++){
        if (j >= VectorGatos.length)
            j=0;
        Mensaje= 'Gato#'+ (i+1) + ': ' + VectorGatos[j] ;
        console.log(Mensaje);
        j++;
    }
}

/* Inciso B */

function IncisoB(VectorEmoticones,CantGatos,CantPasos){
    let Emoticones, Mensaje, i;

    console.log(/-----------IncisoB-----------/);

    Emoticones=VectorEmoticones[0];
    for(i=0; i<CantPasos; i++){
        Emoticones= Emoticones + VectorEmoticones[1];
    }
    for(i=0; i<CantGatos; i++){
        Mensaje= 'Gato#' + (i+1) + ': ' + Emoticones ;
        console.log(Mensaje);
    }
}

