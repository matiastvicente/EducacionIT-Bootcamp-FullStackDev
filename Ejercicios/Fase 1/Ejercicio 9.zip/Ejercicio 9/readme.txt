Algunas consideraciones:

-Le agregue algunos estilos propios, con tipografia externa y algunas pseudoclases. No se si estaba permitido pero me tome la libertad de hacerlo.

-Como no esta aclarado, trate de emular el funcionamiento de una calculadora cientifica, la cual muestra los operadores (+,-,* y /) en el display. 

-Cuando se calculan numeros con muchos decimales, a veces el calculo no es del todo acertado. Desconozco porque pero cuando deberia dar numeros redondos a veces da como resultado con algunos numeros despues de muchos cerosm por ejemplo, una cuenta que deberia dar 3 da 3,00000000005. Esto hace que se rompa un poco el funcionamiento, ya que cuando aparecen mas de 13 digitos en el display agregue que arroje un mensaje de error. Por ende, en ese calculo que deberia mostrar como resultado 3, muestra error (por los decimales ya mencionados). Esto se puede revisar en la consola.